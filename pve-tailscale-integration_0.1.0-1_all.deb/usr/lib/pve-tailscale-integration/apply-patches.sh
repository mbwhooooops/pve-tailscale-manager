#!/bin/bash
set -euo pipefail

python3 <<'PY'
from pathlib import Path

SNIPPET_DIR = Path("/usr/share/pve-tailscale-integration")


def insert_after_once(path_str: str, marker: str, snippet: str, guard: str) -> None:
    path = Path(path_str)
    text = path.read_text()
    if guard in text:
        return
    if marker not in text:
        raise SystemExit(f"marker not found in {path}: {marker!r}")
    text = text.replace(marker, marker + snippet, 1)
    path.write_text(text)


def insert_before_once(path_str: str, marker: str, snippet: str, guard: str) -> None:
    path = Path(path_str)
    text = path.read_text()
    if guard in text:
        return
    if marker not in text:
        raise SystemExit(f"marker not found in {path}: {marker!r}")
    text = text.replace(marker, snippet + marker, 1)
    path.write_text(text)


def append_once(path_str: str, snippet: str, guard: str) -> None:
    path = Path(path_str)
    text = path.read_text()
    if guard in text:
        return
    if not text.endswith("\n"):
        text += "\n"
    text += "\n" + snippet
    path.write_text(text)


nodes_import_snippet = SNIPPET_DIR.joinpath("nodes-import-snippet.txt").read_text()
nodes_register_snippet = SNIPPET_DIR.joinpath("nodes-register-snippet.txt").read_text()
js_menu_snippet = SNIPPET_DIR.joinpath("js-menu-snippet.txt").read_text()
js_panel_snippet = SNIPPET_DIR.joinpath("js-panel-snippet.js").read_text()

insert_after_once(
    "/usr/share/perl5/PVE/API2/Nodes.pm",
    "use PVE::API2::NodeConfig;\n",
    nodes_import_snippet,
    "use PVE::API2::Nodes::Tailscale;\n",
)

insert_after_once(
    "/usr/share/perl5/PVE/API2/Nodes.pm",
    "__PACKAGE__->register_method({\n    subclass => \"PVE::API2::Network::SDN::Nodes::Status\",\n    path => 'sdn',\n});\n",
    nodes_register_snippet,
    "subclass => \"PVE::API2::Nodes::Tailscale\"",
)

insert_before_once(
    "/usr/share/pve-manager/js/pvemanagerlib.js",
    "        if (caps.nodes['Sys.Audit']) {\n            me.items.push(\n                {\n                    xtype: 'pveFirewallRules',\n",
    js_menu_snippet,
    "xtype: 'pveNodeTailscale'",
)

append_once(
    "/usr/share/pve-manager/js/pvemanagerlib.js",
    js_panel_snippet,
    "Ext.define('PVE.node.Tailscale'",
)
PY
