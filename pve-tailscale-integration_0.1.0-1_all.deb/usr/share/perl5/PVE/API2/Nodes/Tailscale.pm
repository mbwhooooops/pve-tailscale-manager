package PVE::API2::Nodes::Tailscale;

use strict;
use warnings;

use JSON qw(decode_json);
use PVE::Exception qw(raise_param_exc);
use PVE::JSONSchema qw(get_standard_option);
use PVE::RESTHandler;
use PVE::Tools;

use base qw(PVE::RESTHandler);

my sub run_tailscale_command {
    my ($cmd) = @_;

    my $stdout = '';
    my $stderr = '';

    PVE::Tools::run_command(
        $cmd,
        outfunc => sub { $stdout .= shift . "\n"; },
        errfunc => sub { $stderr .= shift . "\n"; },
    );

    return ($stdout, $stderr);
}

my sub get_status_json {
    my ($stdout) = run_tailscale_command(['tailscale', 'status', '--json']);
    return decode_json($stdout);
}

my sub get_prefs_json {
    my ($stdout) = run_tailscale_command(['tailscale', 'debug', 'prefs']);
    return decode_json($stdout);
}

my sub normalize_routes {
    my ($routes) = @_;

    return '' if !defined($routes);
    return '' if ref($routes) ne 'ARRAY';

    my @routes = grep { defined($_) && $_ ne '' } @$routes;
    return join(',', @routes);
}

my sub normalize_string_list {
    my ($values) = @_;

    return '' if !defined($values);
    return '' if ref($values) ne 'ARRAY';

    my @values = grep { defined($_) && $_ ne '' } @$values;
    return join(',', @values);
}

my sub bool_to_string {
    my ($value) = @_;
    return $value ? 'true' : 'false';
}

my sub append_flag {
    my ($cmd, $flag, $value) = @_;
    push @$cmd, sprintf('--%s=%s', $flag, $value);
}

my sub append_optional_string_flag {
    my ($cmd, $flag, $value) = @_;

    return if !defined($value);
    return if $value eq '';

    append_flag($cmd, $flag, $value);
}

my sub get_config {
    my $status = eval { get_status_json() } // {};
    my $prefs = eval { get_prefs_json() } // {};

    my $self = $status->{Self} // {};
    my $backend_state = $status->{BackendState} // 'NoState';
    my $routes = normalize_routes($prefs->{AdvertiseRoutes});

    return {
        enabled => ($prefs->{WantRunning} && $backend_state ne 'Stopped') ? 1 : 0,
        backend_state => $backend_state,
        online => $self->{Online} ? 1 : 0,
        hostname => $self->{HostName} // '',
        tailscale_ip => ($self->{TailscaleIPs} && ref($self->{TailscaleIPs}) eq 'ARRAY') ? $self->{TailscaleIPs}->[0] // '' : '',
        accept_routes => $prefs->{RouteAll} ? 1 : 0,
        accept_dns => exists($prefs->{CorpDNS}) ? ($prefs->{CorpDNS} ? 1 : 0) : 1,
        advertise_routes => $routes,
        advertise_tags => normalize_string_list($prefs->{AdvertiseTags}),
        advertise_exit_node => $prefs->{AdvertiseExitNode} ? 1 : 0,
        snat_subnet_routes => exists($prefs->{NoSNAT}) ? ($prefs->{NoSNAT} ? 0 : 1) : 1,
        shields_up => $prefs->{ShieldsUp} ? 1 : 0,
        ssh => $prefs->{RunSSH} ? 1 : 0,
        exit_node => $prefs->{ExitNodeIP} // '',
        exit_node_allow_lan_access => $prefs->{ExitNodeAllowLANAccess} ? 1 : 0,
        operator => $prefs->{OperatorUser} // '',
        hostname_override => $prefs->{Hostname} // '',
    };
}

my sub build_up_command {
    my ($params, $current) = @_;

    my $cmd = ['tailscale', 'up'];
    my $exit_node = $params->{'exit-node'} // $current->{exit_node} // '';
    my $operator = $params->{operator} // $current->{operator};
    my $hostname_override = $params->{hostname} // $current->{hostname_override};
    my $advertise_tags = $params->{'advertise-tags'} // $current->{advertise_tags} // '';

    append_flag($cmd, 'accept-routes', bool_to_string($params->{'accept-routes'} // $current->{accept_routes}));
    append_flag($cmd, 'accept-dns', bool_to_string($params->{'accept-dns'} // $current->{accept_dns}));
    append_flag($cmd, 'advertise-routes', $params->{'advertise-routes'} // $current->{advertise_routes} // '');
    append_flag($cmd, 'advertise-exit-node', bool_to_string($params->{'advertise-exit-node'} // $current->{advertise_exit_node}));
    append_flag($cmd, 'snat-subnet-routes', bool_to_string($params->{'snat-subnet-routes'} // $current->{snat_subnet_routes}));
    append_flag($cmd, 'shields-up', bool_to_string($params->{'shields-up'} // $current->{shields_up}));
    append_flag($cmd, 'ssh', bool_to_string($params->{ssh} // $current->{ssh}));

    if ($advertise_tags ne '') {
        append_flag($cmd, 'advertise-tags', $advertise_tags);
    }

    if ($exit_node ne '') {
        append_flag($cmd, 'exit-node', $exit_node);
        append_flag(
            $cmd,
            'exit-node-allow-lan-access',
            bool_to_string($params->{'exit-node-allow-lan-access'} // $current->{exit_node_allow_lan_access}),
        );
    }

    append_optional_string_flag($cmd, 'operator', $operator);
    append_optional_string_flag($cmd, 'hostname', $hostname_override);

    if (defined($params->{'auth-key'}) && $params->{'auth-key'} ne '') {
        append_flag($cmd, 'auth-key', $params->{'auth-key'});
    }

    return $cmd;
}

__PACKAGE__->register_method({
    name => 'index',
    path => '',
    method => 'GET',
    permissions => {
        check => ['perm', '/nodes/{node}', ['Sys.Audit']],
    },
    parameters => {
        additionalProperties => 0,
        properties => {
            node => get_standard_option('pve-node'),
        },
    },
    returns => {
        type => 'object',
    },
    code => sub {
        my ($param) = @_;

        my $data = get_status_json();
        my $results = $data->{Peer} // {};

        if ($data->{Self}) {
            $results->{$data->{Self}->{PublicKey}} = $data->{Self};
        }

        return $results;
    }});

__PACKAGE__->register_method({
    name => 'config',
    path => 'config',
    method => 'GET',
    permissions => {
        check => ['perm', '/nodes/{node}', ['Sys.Audit']],
    },
    parameters => {
        additionalProperties => 0,
        properties => {
            node => get_standard_option('pve-node'),
        },
    },
    returns => {
        type => 'object',
    },
    code => sub {
        my ($param) = @_;
        return get_config();
    }});

__PACKAGE__->register_method({
    name => 'update_config',
    path => 'config',
    method => 'POST',
    protected => 1,
    permissions => {
        check => ['perm', '/nodes/{node}', ['Sys.Modify']],
    },
    parameters => {
        additionalProperties => 0,
        properties => {
            node => get_standard_option('pve-node'),
            enabled => {
                type => 'boolean',
                optional => 1,
            },
            'accept-routes' => {
                type => 'boolean',
                optional => 1,
            },
            'accept-dns' => {
                type => 'boolean',
                optional => 1,
            },
            'advertise-routes' => {
                type => 'string',
                optional => 1,
            },
            'advertise-tags' => {
                type => 'string',
                optional => 1,
            },
            'advertise-exit-node' => {
                type => 'boolean',
                optional => 1,
            },
            'exit-node' => {
                type => 'string',
                optional => 1,
            },
            'exit-node-allow-lan-access' => {
                type => 'boolean',
                optional => 1,
            },
            'snat-subnet-routes' => {
                type => 'boolean',
                optional => 1,
            },
            'shields-up' => {
                type => 'boolean',
                optional => 1,
            },
            ssh => {
                type => 'boolean',
                optional => 1,
            },
            hostname => {
                type => 'string',
                optional => 1,
            },
            operator => {
                type => 'string',
                optional => 1,
            },
            'auth-key' => {
                type => 'string',
                optional => 1,
            },
        },
    },
    returns => {
        type => 'object',
    },
    code => sub {
        my ($param) = @_;

        raise_param_exc({ enabled => 'at least one setting must be provided' })
            if !defined($param->{enabled})
            && !defined($param->{'accept-routes'})
            && !defined($param->{'accept-dns'})
            && !defined($param->{'advertise-routes'})
            && !defined($param->{'advertise-tags'})
            && !defined($param->{'advertise-exit-node'})
            && !defined($param->{'exit-node'})
            && !defined($param->{'exit-node-allow-lan-access'})
            && !defined($param->{'snat-subnet-routes'})
            && !defined($param->{'shields-up'})
            && !defined($param->{ssh})
            && !defined($param->{hostname})
            && !defined($param->{operator})
            && !defined($param->{'auth-key'});

        my $current = get_config();
        my $enabled = defined($param->{enabled}) ? $param->{enabled} : $current->{enabled};

        if (!$enabled) {
            run_tailscale_command(['tailscale', 'down']);
            return get_config();
        }

        my $cmd = build_up_command($param, $current);
        run_tailscale_command($cmd);

        return get_config();
    }});

1;
