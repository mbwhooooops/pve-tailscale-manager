Ext.define('PVE.node.Tailscale', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.pveNodeTailscale',
    layout: 'fit',

    initComponent: function() {
        var me = this;
        var nodename = me.nodename || (me.pveSelNode && me.pveSelNode.data && me.pveSelNode.data.node) || Proxmox.NodeName;

        var store = Ext.create('Ext.data.Store', {
            fields: ['HostName', 'TailscaleIPs', 'Online'],
            proxy: {
                type: 'proxmox',
                url: '/api2/json/nodes/' + nodename + '/tailscale',
                reader: {
                    type: 'json',
                    rootProperty: function(data) {
                        return Object.values(data.data || {});
                    },
                },
            },
        });

        var configForm = Ext.create('Ext.form.Panel', {
            border: false,
            bodyPadding: 10,
            scrollable: true,
            defaults: {
                anchor: '100%',
                labelWidth: 160,
            },
            items: [
                {
                    xtype: 'displayfield',
                    fieldLabel: gettext('Node'),
                    name: 'hostname',
                },
                {
                    xtype: 'displayfield',
                    fieldLabel: gettext('State'),
                    name: 'backend_state',
                },
                {
                    xtype: 'displayfield',
                    fieldLabel: gettext('Tailscale IP'),
                    name: 'tailscale_ip',
                },
                {
                    xtype: 'textfield',
                    fieldLabel: gettext('Hostname Override'),
                    name: 'hostname_override',
                    emptyText: gettext('Use system hostname'),
                },
                {
                    xtype: 'textfield',
                    fieldLabel: gettext('Operator'),
                    name: 'operator',
                    emptyText: gettext('Optional local user'),
                },
                {
                    xtype: 'proxmoxcheckbox',
                    fieldLabel: gettext('Enabled'),
                    name: 'enabled',
                    uncheckedValue: 0,
                    inputValue: 1,
                },
                {
                    xtype: 'proxmoxcheckbox',
                    fieldLabel: gettext('Accept Routes'),
                    name: 'accept_routes',
                    uncheckedValue: 0,
                    inputValue: 1,
                },
                {
                    xtype: 'proxmoxcheckbox',
                    fieldLabel: gettext('Accept DNS'),
                    name: 'accept_dns',
                    uncheckedValue: 0,
                    inputValue: 1,
                },
                {
                    xtype: 'textfield',
                    fieldLabel: gettext('Advertised Routes'),
                    name: 'advertise_routes',
                    emptyText: '192.168.255.0/24,10.0.0.0/24',
                },
                {
                    xtype: 'textfield',
                    fieldLabel: gettext('Advertised Tags'),
                    name: 'advertise_tags',
                    emptyText: 'tag:router,tag:edge',
                },
                {
                    xtype: 'proxmoxcheckbox',
                    fieldLabel: gettext('Advertise Exit Node'),
                    name: 'advertise_exit_node',
                    uncheckedValue: 0,
                    inputValue: 1,
                },
                {
                    xtype: 'textfield',
                    fieldLabel: gettext('Exit Node'),
                    name: 'exit_node',
                    emptyText: gettext('IP, name or empty'),
                },
                {
                    xtype: 'proxmoxcheckbox',
                    fieldLabel: gettext('Allow LAN Access'),
                    name: 'exit_node_allow_lan_access',
                    uncheckedValue: 0,
                    inputValue: 1,
                },
                {
                    xtype: 'proxmoxcheckbox',
                    fieldLabel: gettext('SNAT Subnet Routes'),
                    name: 'snat_subnet_routes',
                    uncheckedValue: 0,
                    inputValue: 1,
                },
                {
                    xtype: 'proxmoxcheckbox',
                    fieldLabel: gettext('Tailscale SSH'),
                    name: 'ssh',
                    uncheckedValue: 0,
                    inputValue: 1,
                },
                {
                    xtype: 'proxmoxcheckbox',
                    fieldLabel: gettext('Shields Up'),
                    name: 'shields_up',
                    uncheckedValue: 0,
                    inputValue: 1,
                },
                {
                    xtype: 'textfield',
                    inputType: 'password',
                    fieldLabel: gettext('Auth Key'),
                    name: 'auth_key',
                    emptyText: gettext('Optional, only sent on apply'),
                },
            ],
            tbar: [
                {
                    text: gettext('Reload'),
                    handler: function() {
                        loadConfig();
                    },
                },
                {
                    text: gettext('Apply'),
                    handler: function() {
                        var values = configForm.getValues();

                        Proxmox.Utils.API2Request({
                            url: '/nodes/' + nodename + '/tailscale/config',
                            method: 'POST',
                            waitMsgTarget: me,
                            params: {
                                enabled: values.enabled ? 1 : 0,
                                'accept-routes': values.accept_routes ? 1 : 0,
                                'accept-dns': values.accept_dns ? 1 : 0,
                                'advertise-routes': values.advertise_routes || '',
                                'advertise-tags': values.advertise_tags || '',
                                'advertise-exit-node': values.advertise_exit_node ? 1 : 0,
                                'exit-node': values.exit_node || '',
                                'exit-node-allow-lan-access': values.exit_node_allow_lan_access ? 1 : 0,
                                'snat-subnet-routes': values.snat_subnet_routes ? 1 : 0,
                                'shields-up': values.shields_up ? 1 : 0,
                                ssh: values.ssh ? 1 : 0,
                                hostname: values.hostname_override || '',
                                operator: values.operator || '',
                                'auth-key': values.auth_key || '',
                            },
                            success: function() {
                                loadConfig();
                                store.load();
                                configForm.getForm().findField('auth_key').setValue('');
                            },
                            failure: function(response) {
                                Ext.Msg.alert(gettext('Error'), response.htmlStatus);
                            },
                        });
                    },
                },
            ],
        });

        var loadConfig = function() {
            Proxmox.Utils.API2Request({
                url: '/nodes/' + nodename + '/tailscale/config',
                method: 'GET',
                success: function(response) {
                    var data = response.result.data || {};

                    configForm.getForm().setValues({
                        hostname: data.hostname || '',
                        backend_state: data.backend_state || '',
                        tailscale_ip: data.tailscale_ip || '',
                        hostname_override: data.hostname_override || '',
                        operator: data.operator || '',
                        enabled: data.enabled ? 1 : 0,
                        accept_routes: data.accept_routes ? 1 : 0,
                        accept_dns: data.accept_dns ? 1 : 0,
                        advertise_routes: data.advertise_routes || '',
                        advertise_tags: data.advertise_tags || '',
                        advertise_exit_node: data.advertise_exit_node ? 1 : 0,
                        exit_node: data.exit_node || '',
                        exit_node_allow_lan_access: data.exit_node_allow_lan_access ? 1 : 0,
                        snat_subnet_routes: data.snat_subnet_routes ? 1 : 0,
                        ssh: data.ssh ? 1 : 0,
                        shields_up: data.shields_up ? 1 : 0,
                        auth_key: '',
                    });
                },
                failure: function(response) {
                    Ext.Msg.alert(gettext('Error'), response.htmlStatus);
                },
            });
        };

        var peerGrid = Ext.create('Ext.grid.GridPanel', {
            border: false,
            store: store,
            columns: [
                { header: 'Host', dataIndex: 'HostName', flex: 1 },
                {
                    header: 'IP',
                    dataIndex: 'TailscaleIPs',
                    width: 180,
                    renderer: function(v) { return (v && v.length) ? v[0] : ''; },
                },
                {
                    header: 'Status',
                    dataIndex: 'Online',
                    width: 100,
                    renderer: function(v) { return v ? 'Online' : 'Offline'; },
                },
            ],
            tbar: [
                {
                    text: gettext('Reload'),
                    handler: function() {
                        store.load();
                    },
                },
            ],
        });

        Ext.apply(me, {
            items: [
                {
                    xtype: 'tabpanel',
                    border: false,
                    items: [
                        {
                            xtype: 'panel',
                            title: gettext('Configuration'),
                            layout: 'fit',
                            border: false,
                            items: [configForm],
                        },
                        {
                            xtype: 'panel',
                            title: gettext('Peers'),
                            layout: 'fit',
                            border: false,
                            items: [peerGrid],
                        },
                    ],
                }
            ],
        });

        me.callParent();
        loadConfig();
        store.load();
    },
});
